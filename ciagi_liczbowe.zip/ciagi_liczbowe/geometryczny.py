def geo(a1,n,q):
    print("Wzor na n-ty wyraz ciagu geometrycznego:")
    wzor=a1*q**(n-1)
    return wzor
    print("Wzor na sume poczatkowych n wyrazow.Podaj a1, n, q")
    if q==1:
        wzor2=n*a1
        return wzor2
    else:
        wzor3=a1*((1-q**n)/(1-q))
        return wzor3
print(geo(1,2,3))