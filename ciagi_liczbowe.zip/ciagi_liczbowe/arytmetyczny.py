def ary(a1,n,r):
    print("Wzor na n-ty wyraz ciagu arytmetycznego:")
    wzor=a1+(n-1)*r
    return wzor
    print("Wzor na sume poczatkowych n wyrazow. Podaj a1, n, r")
    wzor2=(a1+an)/2*n
    return wzor2
print(ary(1,2,3))